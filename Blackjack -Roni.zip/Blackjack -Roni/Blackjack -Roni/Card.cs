﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack__Roni
{
    class Card
    {

        public enum Suites
        {
            Clubs,
            Hearts,
            Spades,
            Diamonds
        }

        public int value { get; set; }

        public Suites Suite { get; set; }


        //public static List<Suites> AllSuites = Enum.GetValues(typeof(Suites));

        //Constructor
        public Card(int value, Suites Suite)
        {
            this.value = value;
            this.Suite = Suite;
        }

        public int getPoints()
        {
            switch(value)
            {
                case 11:
                case 12:
                case 13:
                    return 10;
                default:
                    return value;

            }
        }

        // static == ei tarvitse ensin objektia
        public static Bitmap GetPictureResourcex(string key)
        {
            return Blackjack__Roni.Card_Pictures.ResourceManager.GetObject(key) as Bitmap;
        }

        public string getPictureKey()
        {
            char suite = getSuiteId();
            string value = getValueId();
            return suite + value;
        }

        // return suiteId as 'C' or 'H' or 'D' or 'S'
        private char getSuiteId()
        {
            switch(Suite.ToString())
            {
                case "Hearts": return 'H';
                case "Diamonds": return 'D';
                case "Clubs": return 'C';
                case "Spades": return 'S';
                default: return 'X';
            }
        }

        private string getValueId()
        {
            switch(value)
            {
                case 11: return "J";
                case 12: return "Q";
                case 13: return "K";
                default: return value.ToString();
            }
        }

    }
}
