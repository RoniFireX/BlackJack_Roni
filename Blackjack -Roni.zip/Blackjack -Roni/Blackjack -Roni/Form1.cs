﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using System.Media;

namespace Blackjack__Roni
{
    public partial class Form1 : Form
    {

        Deck playDeck = new Deck();
        Deck dealerCards = new Deck();
        Deck playerCards = new Deck();

        int dealerWins = 0;
        int playerWins = 0;

        int saldo = 1000;

        Deck calculateOddsDeck = new Deck();

        bool hideFirst = true;

        public static Dictionary<string, Bitmap> CARD_PICTURES =
            new Dictionary<string, Bitmap>();

        bool gameStarted = false;

        private System.Timers.Timer timer = null;
        bool autoPlay = false;

        //Constructor
        public Form1()
        {

            InitializeComponent();

            playDeck.fillDeck();
            calculateOddsDeck.fillDeck();

            foreach (Card c in playDeck.cardsList)
            {
                string key = c.getPictureKey(); //maa + arvo

                CARD_PICTURES.Add(key, Card.GetPictureResourcex(key));
            }

            int helper = 5;

            button3.Enabled = false;
            button4.Enabled = false;
            button6.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label25.Text = 1000 + "$";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            button1.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = true;

            play();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            hit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pass();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tuplaa();
        }

        private void updateScene()
        {

            //Check gamestate
            button2.Enabled = !gameStarted;

            if (hideFirst && gameStarted)
            {
                label14.Text = "?";
                label13.Text = playerCards.countPoints().ToString();


                label16.Text = String.Format("{0:0.00}" + "%",
                    OddsCalculator.DealerWins(dealerCards.cardsList[1], playerCards.countPoints()));
            }
            else
            {
                label14.Text = dealerCards.countPoints().ToString();

                label15.Text = OddsCalculator.OverDraw(playDeck, calculateOddsDeck).ToString();
            }

            label17.Text = (playerWins - dealerWins).ToString();

            //dealer
            label14.Text = dealerCards.countPoints().ToString();
            //Player
            label13.Text = playerCards.countPoints().ToString();

            label15.Text = String.Format("{0:0.00}" + "%",
                OddsCalculator.OverDraw(playerCards, calculateOddsDeck));

            //label15.Text = OddsCalculator.OverDraw(playerCards, calculateOddsDeck).ToString();

            List<Label> playerLabels = new List<Label>
            {
                label6,
                label7,
                label8,
                label9,
                label10

            };
            List<Label> dealerLabels = new List<Label>
            {
                label1,
                label2,
                label3,
                label4,
                label5
            };

            List<PictureBox> playerBoxes = new List<PictureBox>
            {
                pictureBox1,
                pictureBox2,
                pictureBox3,
                pictureBox4,
                pictureBox5
            };

            List<PictureBox> dealerBoxes = new List<PictureBox>
            {
                pictureBox6,
                pictureBox7,
                pictureBox8,
                pictureBox9,
                pictureBox10
            };

            //player 4th parameter is false due to never hiding cards
            renderCards(playerLabels, playerBoxes, playerCards.cardsList, false);
            //dealer
            renderCards(dealerLabels, dealerBoxes, dealerCards.cardsList, hideFirst);
        }

        private void renderCards(List<Label> labels, List<PictureBox> boxes, List<Card> cards, bool hide)
        {
            bool cardHidden = false;
            IEnumerator enumerator =
                cards.GetEnumerator();
            IEnumerator enumeratorBoxes = boxes.GetEnumerator();

            foreach (Label i in labels)
            {
                Card c = enumerator.MoveNext() ?
                    (Card)enumerator.Current : null;

                PictureBox pb = enumeratorBoxes.MoveNext()
                    ? (PictureBox)enumeratorBoxes.Current : null;

                if (hide == true && cardHidden == false)
                {
                    label14.Text = "";
                    pb.Image = Card.GetPictureResourcex("reversed");
                    cardHidden = true;
                }

                else if (c != null && pb != null)
                {
                    i.Text = (c.value.ToString() + " " + c.Suite);
                    pb.Image = Card.GetPictureResourcex(c.getPictureKey());
                }
                else
                {
                    i.Text = "";
                    pb.Image = null;
                }
            }
        }

        private void reset()
        {
            if (autoPlay)
            {
                updateScene();
            }

            gameStarted = false;
            dealerCards.cardsList.Clear();
            playerCards = new Deck();
            hideFirst = true;

            button1.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;


            if (!autoPlay)
            {
                updateScene();
            }

            //Laita näkyviin (Ei toiminut updateScenessä)
            //button2.Visible = true; //false
            //button3.Visible = false;
            //button4.Visible = false;
        }

        //start autoplay
        private void button5_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button6.Enabled = false;

            autoPlay = true;

            timer = new System.Timers.Timer((double)numericUpDown1.Value);
            timer.Elapsed += autoPlayTimerEvent;
            timer.AutoReset = true;
            timer.Enabled = true;

            updateScene();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            autoPlay = false;
            timer.AutoReset = false;
            timer.Enabled = false;

            button2.Enabled = true;

            updateScene();
        }


        private void autoPlayTimerEvent(Object source, ElapsedEventArgs e)
        {
            this.Invoke(new MethodInvoker(delegate ()
           {
               if (playDeck.cardsList.Count() < 400)
               {
                   playDeck.cardsList.Clear();
                   for (int i = 0; i < 10; i++)
                   {
                       playDeck.fillDeck();
                   }
               }

               play();

           }));
        }

        private void play()
        {
            hideFirst = true;
            gameStarted = true;
            button3.Enabled = true;
            button4.Enabled = true;

            dealerCards.cardsList.Add(playDeck.pickCard());
            dealerCards.cardsList.Add(playDeck.pickCard()); // näytä kortti väärinpäi

            playerCards.cardsList.Add(playDeck.pickCard());
            playerCards.cardsList.Add(playDeck.pickCard());

            //if (!autoPlay)
            {
                updateScene();
            }

            if (playerCards.countPoints() == 21)
            {
                BJWin();
            }
            else if (autoPlay == true)
            {
                autoPlayHit();
            }
        }

        private void hit()
        {
            playerCards.cardsList.Add(playDeck.pickCard());

            if (!autoPlay)
            {
                updateScene();
            }

            if (playerCards.countPoints() > 21 && !autoPlay)
            {
                Lose();
            }
        }

        private void tuplaa()
        {
            playerCards.cardsList.Add(playDeck.pickCard());
            button3.Enabled = false;
            button4.Enabled = false;

            if (!autoPlay)
            {
                updateScene();
            }

            if (playerCards.countPoints() > 21)
            {
                Lose();
            }

            pass();
        }

        private void autoPlayHit()
        {
            bool passing = false;
            //draw cards
            while (passing == false)
            {
                if (OddsCalculator.DealerWins(dealerCards.cardsList[1], playerCards.countPoints()) < 50)
                {
                    passing = true;
                }
                else if (OddsCalculator.OverDraw(playerCards, calculateOddsDeck) < OddsCalculator.DealerWins(dealerCards.cardsList[1], playerCards.countPoints()))
                {
                    hit();
                }
                else
                {
                    passing = true;
                }
            }

            //lose if overdraw > 21
            if (playerCards.countPoints() > 21)
            {
                Lose();
            }
            else
            {
                pass(); //stay
            }
        }

        private void pass()
        {
            hideFirst = false;
            while (dealerCards.countPoints() < 17)
            {

                dealerCards.cardsList.Add(playDeck.pickCard());

            }

            updateScene();

            //Tarkistetaan voittaja

            if (dealerCards.countPoints() > 21)
            {
                Win();
            }

            else if (dealerCards.countPoints() == playerCards.countPoints())
            {
                Tie();
            }

            else if (dealerCards.countPoints() >= playerCards.countPoints())
            {
                Lose();
            }
            else
            {
                Win();
            }
        }

        //bet
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        /*private void playSimpleSound()
        {
            SoundPlayer simpleSound = new SoundPlayer(@"C:\Users\roni.hagman\Documents\Visual Studio 2015\Projects\Blackjack -Roni\Blackjack -Roni\Resources\Lose.wav");
            simpleSound.Play();
        }*/

        //Tekstit
        private void Lose()
        {
            //playSimpleSound();

            label23.Text = "";

            saldo = saldo - 50;

            dealerWins++;
            if (!autoPlay)
            {
                MessageBox.Show("Hävisit pelin!" + " | " + "Diilerillä oli: " + dealerCards.countPoints());
            }
            reset();
        }

        private void Win()
        {
            label23.Text = "";

            saldo = saldo + 50;

            playerWins++;
            if (!autoPlay)
            {
                MessageBox.Show("Voitit pelin! Sait = " + playerCards.countPoints() + " | " + "Diilerillä oli = " + dealerCards.countPoints());
            }
            reset();
        }

        private void Tie()
        {
            label23.Text = "";

            if (!autoPlay)
            {
                MessageBox.Show("Tasapeli!");
            }
            reset();
        }

        private void BJWin()
        {
            label23.Text = "";
            saldo = saldo + 75;

            if (!autoPlay)
            {
                MessageBox.Show("Blackjack!");
            }
            reset();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.WindowState = FormWindowState.Normal;
            this.Focus(); this.Show();
        }

        private void pictureBoxChip5_Click(object sender, EventArgs e)
        {
            int panos1 = 5;

            int mo1 = saldo - panos1;
            label23.Text = Convert.ToString(panos1) + "$";
            label25.Text = Convert.ToString(mo1) + "$";

        }

        private void pictureBoxChip25_Click(object sender, EventArgs e)
        {
            int panos2 = 25;

            int mo2 = saldo - panos2;
            label23.Text = Convert.ToString(panos2) + "$";
            label25.Text = Convert.ToString(mo2) + "$";
        }

        private void pictureBoxChip50_Click(object sender, EventArgs e)
        {
            int panos3 = 50;

            int mo3 = saldo - panos3;
            label23.Text = Convert.ToString(panos3) + "$";
            label25.Text = Convert.ToString(mo3) + "$";
        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }
    }
}
