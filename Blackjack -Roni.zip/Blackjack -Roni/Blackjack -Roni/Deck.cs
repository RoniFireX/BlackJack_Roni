﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack__Roni
{
    class Deck
    {
        public List<Card> cardsList = new List<Card>();
        private static Random RNG = new Random();

        public void fillDeck()
        {

            Card.Suites suiteH = (Card.Suites)(0);
            Card.Suites suiteD = (Card.Suites)(1);
            Card.Suites suiteC = (Card.Suites)(2);
            Card.Suites suiteS = (Card.Suites)(3);


            //Loop through card values 1-10
            for (int i = 1; i <= 13; i++)
            {
                //loop through each suite in deck
                //foreach (Card.Suites suite in Card.Suites)
                //{
                //}
                cardsList.Add(new Card(i, suiteH));
                cardsList.Add(new Card(i, suiteD));
                cardsList.Add(new Card(i, suiteC));
                cardsList.Add(new Card(i, suiteS));

            }
        }

        static Random r = new Random();
        public void Shuffle()
        {
            /*n--;
            int randomIndex = rng.Next(n + 1); // n = 52
            Card temp = cardsList[randomIndex]*/


            for (int n = cardsList.Count - 1; n > 0; --n)
            {
                int k = RNG.Next(n + 1);
                Card temp = cardsList[n];
                cardsList[n] = cardsList[k];
                cardsList[k] = temp;
            }
        }

        public Card pickCard()
        {
            int randomIndex = RNG.Next(cardsList.Count);
            Card temp = cardsList[randomIndex];
            cardsList.RemoveAt(randomIndex);
            return temp;
        }

        public int countPoints()
        {
            int total = 0;
            foreach (Card c in cardsList)
            {
                total += c.getPoints();
            }
            return total;
           
        }

        public int countPointsAceOne()
        {
            int returnValue = 0;
            int aces = 0;

            foreach (Card c in cardsList)
            {
                if(c.value == 1)
                {
                    aces++;
                }
                returnValue += c.getPoints();
            }

            for (int i = 0; i < aces; i++)
            {
                returnValue -= 10;
            }


            return returnValue;
        }


    }
}
